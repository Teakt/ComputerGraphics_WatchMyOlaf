TEAK Guillaume

---------------------------------

Created 3 VAOs, one for the grid, one for the axis, one for the olaf using one cube.